package com.example.calculetor;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    private EditText billAmount;
    private Switch switch10;
    private Switch switch15;
    private Switch switch20;
    private SeekBar splitBy;
    private Button calculateButton;
    private TextView resultTextView;

    // Constants for tip percentages
    private static final int TIP_PERCENTAGE_10 = 10;
    private static final int TIP_PERCENTAGE_15 = 15;
    private static final int TIP_PERCENTAGE_20 = 20;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize the UI elements by finding them in the layout
        billAmount = findViewById(R.id.editTextTextPersonName2);
        switch10 = findViewById(R.id.switch1);
        switch15 = findViewById(R.id.switch2);
        switch20 = findViewById(R.id.switch3);
        splitBy = findViewById(R.id.seekBar);
        calculateButton = findViewById(R.id.button);
        resultTextView = findViewById(R.id.editTextTextPersonName3);

        // Set up TextWatcher for input validation
        billAmount.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Do nothing
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Validate input
                if (!s.toString().matches("\\d+(\\.\\d{1,2})?")) {
                    billAmount.setError("Invalid input");
                } else {
                    billAmount.setError(null);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                // Do nothing
            }
        });

        // Set the onClickListener for the calculate button
        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateAndDisplayBill();
            }
        });
    }

    // Method to calculate and display the bill
    private void calculateAndDisplayBill() {
        // Get the values from the UI elements
        double bill = Double.parseDouble(billAmount.getText().toString());
        double tip = 0;
        if (switch10.isChecked()) tip = TIP_PERCENTAGE_10;
        else if (switch15.isChecked()) tip = TIP_PERCENTAGE_15;
        else if (switch20.isChecked()) tip = TIP_PERCENTAGE_20;

        int people = splitBy.getProgress(); // Assuming the SeekBar is set up with max value and progress correctly

        // Calculate the total bill including the tip
        double totalTip = bill * (tip / 100);
        double totalBill = bill + totalTip;

        // Calculate the amount per person if people is not 0 to avoid division by zero
        double amountPerPerson = people!= 0? totalBill / people : totalBill;

        // Display the results
        resultTextView.setText("Total Bill: " + String.format("%.2f", totalBill) +
                "\nEach Person Pays: " + String.format("%.2f", amountPerPerson));
    }
}